#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.IO;

[InitializeOnLoad]
public static class AutoBuildOnLoad
{
    static AutoBuildOnLoad()
    {
        EditorApplication.update += RunOnce;
    }

    static void RunOnce()
    {
        EditorApplication.update -= RunOnce;
        TryBuildSceneIfMissing();
    }

    static void TryBuildSceneIfMissing()
    {
        string scenePath = "Assets/Scenes/MyFirstScene.unity";
        if(File.Exists(scenePath)) return;
        BuildScene(scenePath);
    }

    static void BuildScene(string scenePath)
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // Create Ground plane
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.position = Vector3.zero;
        ground.transform.localScale = new Vector3(5,1,5);

        // Create and apply a basic material if possible
        if(!Directory.Exists("Assets/Materials")) Directory.CreateDirectory("Assets/Materials");
        Shader urp = Shader.Find("Universal Render Pipeline/Lit");
        Shader shaderToUse = urp != null ? urp : Shader.Find("Standard");
        var mat = new Material(shaderToUse) { name = "GroundMat" };
        AssetDatabase.CreateAsset(mat, "Assets/Materials/Ground.mat");
        var rend = ground.GetComponent<Renderer>();
        if(rend) rend.sharedMaterial = mat;

        // Disable existing Main Camera(s)
        foreach(var c in GameObject.FindObjectsOfType<Camera>())
            if(c.CompareTag("MainCamera")) c.gameObject.SetActive(false);

        // Create Player
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "PlayerCharacter";
        player.transform.position = new Vector3(0,1,0);
        Object.DestroyImmediate(player.GetComponent<Collider>());
        player.AddComponent<CharacterController>();
        player.AddComponent<PlayerController>();

        // Create Player Camera
        GameObject cam = new GameObject("PlayerCamera");
        var cameraComp = cam.AddComponent<Camera>();
        cameraComp.tag = "MainCamera";
        cam.transform.position = new Vector3(0,2,-6);
        cam.transform.rotation = Quaternion.Euler(10,0,0);
        var follow = cam.AddComponent<FollowTarget>();
        follow.target = player.transform;
        follow.offset = new Vector3(0,2,-4);

        // Create spawner and spawn cubes
        GameObject spawner = new GameObject("CubeSpawner");
        spawner.transform.position = new Vector3(0,0,3);
        var spawnComp = spawner.AddComponent<Spawner>();
        spawnComp.rows = 4;
        spawnComp.cols = 4;
        spawnComp.spacing = 1.1f;
        spawnComp.SpawnStack();

        // Create simple VFX prefab (ParticleSystem)
        if(!Directory.Exists("Assets/Prefabs")) Directory.CreateDirectory("Assets/Prefabs");
        GameObject vfx = new GameObject("SimpleVFX");
        vfx.AddComponent<ParticleSystem>();
        PrefabUtility.SaveAsPrefabAsset(vfx, "Assets/Prefabs/SimpleVFX.prefab");

        // Save player as prefab
        PrefabUtility.SaveAsPrefabAsset(player, "Assets/Prefabs/PlayerCharacter.prefab");

        // Save the scene
        if(!Directory.Exists(Path.GetDirectoryName(scenePath))) Directory.CreateDirectory(Path.GetDirectoryName(scenePath));
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("AutoBuild", "Scene created: " + scenePath, "OK");
    }
}
#endif
