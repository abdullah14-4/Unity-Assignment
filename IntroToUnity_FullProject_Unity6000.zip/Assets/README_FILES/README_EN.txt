IntroToUnity - Unity 6000.0.41f1 Project (Auto-build)
--------------------------------------------------
What this archive contains:
- Scripts: PlayerController, FollowTarget, Spawner
- Editor script (AutoBuildOnLoad) that will create the sample scene on first open
- Prefab placeholders created at runtime: PlayerCharacter.prefab, SimpleVFX.prefab
- ProjectVersion.txt set to Unity 6000.0.41f1

How to use:
1. Unzip this folder.
2. Open Unity Hub and choose 'Open' then select this project folder.
3. Open with Unity 6000.0.41f1. Wait for scripts to compile.
4. The editor script will create Assets/Scenes/MyFirstScene.unity if missing.
5. Open the scene and press Play to test (WASD movement, Space=jump).

Note: I cannot run Unity here to pre-save the .unity scene file, so Unity will generate the scene automatically when you open the project and scripts compile.
