مشروع IntroToUnity - Unity 6000.0.41f1 (إعداد تلقائي)
--------------------------------------------------
محتويات الحزمة:
- سكربتات: PlayerController, FollowTarget, Spawner
- سكربت محرر (AutoBuildOnLoad) يقوم بإنشاء المشهد تلقائياً عند فتح المشروع
- Prefab سيتم إنشاؤه أثناء التشغيل: PlayerCharacter.prefab, SimpleVFX.prefab
- ProjectVersion.txt مضبوط على Unity 6000.0.41f1

طريقة الاستخدام:
1. فك الضغط عن هذه الحزمة.
2. افتح Unity Hub واختر 'Open' ثم اختر مجلد المشروع.
3. افتح المشروع باستخدام Unity 6000.0.41f1 وانتظر تجميع السكربتات.
4. السكربت سيولد المشهد Assets/Scenes/MyFirstScene.unity إذا لم يكن موجوداً.
5. افتح المشهد واضغط Play للتجربة (WASD للتحرك، Space للقفز).
