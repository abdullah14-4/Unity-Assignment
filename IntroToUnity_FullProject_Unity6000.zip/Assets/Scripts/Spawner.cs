using UnityEngine;

public class Spawner : MonoBehaviour
{
    public int rows = 3;
    public int cols = 3;
    public float spacing = 1.1f;

    public void SpawnStack()
    {
        for(int y=0; y<rows; y++)
        {
            for(int x=0; x<cols; x++)
            {
                Vector3 pos = transform.position + new Vector3((x - (cols-1)/2.0f) * spacing, y * 1.05f + 0.5f, 0);
                GameObject c = GameObject.CreatePrimitive(PrimitiveType.Cube);
                c.transform.position = pos;
                c.AddComponent<Rigidbody>();
            }
        }
    }
}
